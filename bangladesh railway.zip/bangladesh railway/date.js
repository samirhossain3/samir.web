


var date = new Date ()


// console.log(date.toDateString())

// console.log(date.toTimeString())
// console.log(date.toLocaleString())
// console.log(date.getHours())
// console.log(date.getMinutes())
// console.log(date.getSeconds())
// console.log(date.getTime())

// console.log(date.getFullYear())
// console.log(date.getMonth())
// console.log(date.getDate()) 



// 0 - Sunday,  1 - monday , 2 - Tuesday 

var year = date.getMonth()

switch ( year  ){
    case 0:
    console.log('this month is 1  ')

    break


    case 1:
        console.log('this month is 4 ')

        break

    
        case 2:
            console.log('this month is 3 ')
    
            break
    

            case 3:
        console.log('this month is 4 ')

        break

    
        case 4:
            console.log('this month is 5 ')
    
            break
    

            
        case 5:
            console.log('this month is jun ')
    
            break
    
            
        case 6:
            console.log('this month is july ')
    
            break
    

            
        case 8 :
            console.log('this month is september ')
    
            break
    
}













