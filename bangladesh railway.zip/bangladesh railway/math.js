console.log(Math.E)


console.log(Math.PI)


var n = 41.5

console.log(Math.abs(n))
console.log(Math.floor(n))
console.log(Math.ceil(n))
console.log|(Math.round(n))


console.log(Math.pow(2,3)) 




console.log(Math.round(Math.random() * 50 +1 ))


alert("hello ")

console.log('welcome to bangladesh ' + 2 )
