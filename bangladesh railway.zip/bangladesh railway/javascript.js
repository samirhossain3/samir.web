
// // var name = 'developer samir'
// // var age = 25  + ' years old'




// // //console.log( name)
// // //console.log(age)

// // console.log( name + ' knows javascirpt')
// // console.log( 'His age is only ' + age )
// // console.log(name+' make a javascirpt coures ')
// // console.log('But his age is only  ' + age)




// // var n  = 15454254

// // var f = Number('3.2156')
// // var nn = Number('2.0')

// // console.log(nn)

// // console.log(Number.MAX_VALUE)
// // console.log(Number.MIN_SAFE_INTEGER)


// // console.log(10-8)

// // console.log ('10000'* 100)



// // var fff = 'hello '
// // var fff1 = "hello "
// // var fff2 =`hello `
// // var fff4 = String('bbvhjbdbb')
// // var fff5 =String(2154)
// // var fff6 = 5654 

// // console.log(fff, fff1, fff2 ,  fff4, fff5, fff6 )



// // console.log( name * age )


// // var hh = '100'
// // var hhh = 2

// // console.log(hh - hhh )

// // console.log(Number.parseInt(hh))
// // console.log(Boolean(Infinity))

// // console.log (hh.toString())

// // console.log(Boolean())

// // console.log(Boolean(null))

// // console.log(Boolean(undefined))





// // console.log(Boolean( 'developer '))
// // console.log(Boolean(0))





// // var a = 50
// // var b  = 7


// // console.log( a % b )


// // console.log(a--)


// // var a = 40
// // var b = 10


// // a +=  b 

// // console.log(a)


// // a -= b 

// // console.log(b)









// // console.log(154156 + '258')
// // console.log(2 + 5+ 5)

// // var gg = 'developer'
// // var name = samir  
// // var age  = 18

// // console.log('hossain')


// // console.log(  'web developer' )

// // var post = 'developer '

// // var name  = 'samir '

// // var age = 18 


// // console.log( 'web ' + post + name
// //  + ' hossain ' + 'His age is ' + age )


// // var a = 40
// // var b = 30
// // console.log(a==b)
// // console.log(a  !=  b)

// // console.log(a>b)
// //  console.log(a<b)
 
// // console.log(a >= b )
// // console.log(a <= b )




// // var c ='50'
// // var d =50

// // console.log(c===d )

// // console.log(c !== d )


// // // Bitwise Oparators
// // // &
// // // !
// // // 











// // var  a=10 
// // var b =20

// // var c = a>= b 


// // ^

// //    console.log(' developer samir and mst  buri khatun ')



// //    var name = 'mst moriom khatun '
// //    var age = 12 

// // console.log(Math.E)
// //  console.log(Math.PI)

// // console.log(5.08)


// // var a = 9.2

// // console.log(Math.abs(a))

// // console.log(Math.floor(a))
// // console.log(Math.ceil(a))
// // console.log(Math.round(a))
// // console.log(Math.max(100,500,700))
// // console.log(Math.max (100,500,545))

// // console.log(Math.pow(3, 8))
// // console.log(Math.sqrt(49))

// // console.log(Math.round(Math.random() * 80+2))

// // var a = 1500000
// // var b = 10000


// // if( a > b ){
// //    console.log(  a + 'is b ar boro ' + b) 
// // } else{
// //     console.log( a+ 'is b ar soto' + b)
// // }

// // var n = 54564642

// // if(n % 2 === 0 ){
// //    console.log( n + 'is zor number ')
// // }

// // else{
// //     console.log( n + 'is bizor number ')
// //  }

// // var name1 = 'lito'
// // var name2 = 'moriom'
// // var name3 = 'zubaer'

// // if(name1 > name3 > name2 ) {
// // console.log( name3 + 'onik boro ' + name1 )
// // }else{
// //     console.log( name3 + 'onik soto ' + name1 + name2 + 'ar caitay' + 'taow koto ta?????' )
// // }

// // var  nn = '100'
// // var n = 100
// // console.log(Number(nn))
// // console.log(n.toString())

// // console.log(Boolean(Infinity))



//  var hexav =0xfdcdfccaf

//  console.log(hexav )

// var oactal = 0252


// console.log(oactal)

