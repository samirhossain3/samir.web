// var a = 30 
// var b = 2


// // a > b true false 

// if ( a > b  ) {
   
//     console.log(  ' A  is greater than  B '  )
// }


// if (a<b) {

//     console.log(' B is greater than A ')
// }


// var n = 50 

// if(n % 2 === 0 ){
//     console.log(n+' is Eiven number ')
// }



// if( n % 2 === 1 ){
//     console.log (  n +  ' is odd number ')
// }








// var a = 50
// var b = 300



// if(a >s b)  {
//     console.log(' A ar caiay b boro')
// }




// if( a < b ){
//     console.log('b ar caiay a boro')
// }





// var s = 50

// if( s % 2 === 1){ 
//     console.log( s + 'very good number' )
// }


// if( n % 2 === 1 ){
//     console.log (  n +  ' is odd number ')
// }

// var name = 'samir' 
// var age = 18 


// console.log( name + 'hossain ' + 'and he is ' + age + 'years old ' )



